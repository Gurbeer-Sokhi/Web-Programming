const recipedata = require('./recipe');
const userdata = require('./user');

module.exports={
    recipedata,userdata
}
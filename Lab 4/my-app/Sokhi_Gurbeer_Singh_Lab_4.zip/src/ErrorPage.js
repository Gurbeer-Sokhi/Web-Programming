import "./App.css";

export default function ErrorPage() {
  console.log("In");
  return (
    <div>
      <h1>404 Not Found</h1>
    </div>
  );
}

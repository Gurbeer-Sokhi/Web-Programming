import "./App.css";

export default function Pagination() {
  console.log("In");
  return <div></div>;
}
